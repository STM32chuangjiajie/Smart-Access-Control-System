#include "stm32f10x.h"                  // Device header
#include "beep.h"              

//��������ʼ��
void Beep_Init(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
	GPIO_InitTypeDef GPIO_InitStructrue;
	GPIO_InitStructrue.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructrue.GPIO_Pin = GPIO_Pin_12;
	GPIO_InitStructrue.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA,&GPIO_InitStructrue);
}

//����������
void Beep(u8 state)
{
	GPIO_WriteBit(GPIOA,GPIO_Pin_12,(BitAction)state);
}
#ifndef __beep_H
#define __beep_H
#include "stm32f10x.h"                  // Device header

void Beep_Init(void);
void Beep(u8 state);

#endif

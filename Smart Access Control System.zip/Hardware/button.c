#include "stm32f10x.h"                  // Device header
#include <delay.h>
#include "usart.h"
#include "button.h"
//������ʼ��
void Button_init()
{
	
 
 	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);//ʹ��PORTBʱ��
 	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO,ENABLE);//ʹ�ܸ���ʱ��

	GPIO_PinRemapConfig(GPIO_Remap_SWJ_JTAGDisable,ENABLE); //����GIOB
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; 		 //�������
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;		 //IO���ٶ�Ϊ50MHz
	GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_3|GPIO_Pin_4;
 	GPIO_Init(GPIOB, &GPIO_InitStructure);//��ʼ��GPIOB0.1.2.3

	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD; //���ó���������
	GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_5|GPIO_Pin_6|GPIO_Pin_7|GPIO_Pin_8;	
	GPIO_Init(GPIOB, &GPIO_InitStructure);//��ʼ��GPIOB5.6.7.8
}

//����ɨ��
int Button_Scan()
{
	int keyValue=0;//����ֵ
	
	//����ȫ�����ߣ�����Ƿ񰴼�����
	GPIO_WriteBit(GPIOB,GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_3|GPIO_Pin_4,Bit_SET);//0134����
	if( (GPIO_ReadInputData(GPIOB) & 0x01e0 )==0x0000) //B5.6.7.8��λΪ�͵�ƽ���ް�������
		return -1;
	else
	{
		delay_ms(20);
		
		if((GPIO_ReadInputData(GPIOB) & 0x01e0)==0x0000)
		return -1;	
	}
	//����B1��2��3������B0�����ڼ������Ű���
	GPIO_WriteBit(GPIOB, GPIO_Pin_1 | GPIO_Pin_3 | GPIO_Pin_4, Bit_RESET);
	GPIO_WriteBit(GPIOB, GPIO_Pin_0, Bit_SET);
//	printf("0x%x\r\n",GPIOB->IDR & 0x00f0);
	  switch(GPIO_ReadInputData(GPIOB) & 0x01e0)
		{
			case 0x0020 : keyValue=13;break;
			case 0x0040 : keyValue=14;break;
			case 0x0080 : keyValue=15;break;
			case 0x0100 : keyValue=16;break;	
		}while((GPIO_ReadInputData(GPIOB) & 0x01e0)!=0x0000);

	GPIO_WriteBit(GPIOB, GPIO_Pin_0 | GPIO_Pin_3 | GPIO_Pin_4, Bit_RESET);
	GPIO_WriteBit(GPIOB, GPIO_Pin_1, Bit_SET);
//	printf("0x%x\r\n",GPIOB->IDR & 0x0080);
	  switch(GPIO_ReadInputData(GPIOB) & 0x01e0)
		{
			case 0x0020 : keyValue=9;break;
			case 0x0040 : keyValue=10;break;
			case 0x0080 : keyValue=11;break;
			case 0x0100 : keyValue=12;break;	
		}while((GPIO_ReadInputData(GPIOB) & 0x01e0)!=0x0000);

	GPIO_WriteBit(GPIOB, GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_4, Bit_RESET);
	GPIO_WriteBit(GPIOB, GPIO_Pin_3, Bit_SET);
//	printf("0x%x\r\n",GPIOB->IDR & 0x00f0);
	  switch(GPIO_ReadInputData(GPIOB) & 0x01e0)
		{
			case 0x0020 : keyValue=5;break;
			case 0x0040 : keyValue=6;break;
			case 0x0080 : keyValue=7;break;
			case 0x0100 : keyValue=8;break;	
		}while((GPIO_ReadInputData(GPIOB) & 0x01e0)!=0x0000);

	
	GPIO_WriteBit(GPIOB, GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_3, Bit_RESET);
	GPIO_WriteBit(GPIOB, GPIO_Pin_4, Bit_SET);
//	printf("0x%x\r\n",GPIOB->IDR & 0x00f0);
	  switch(GPIO_ReadInputData(GPIOB) & 0x01e0)
		{
			case 0x0020 : keyValue=1;break;
			case 0x0040 : keyValue=2;break;
			case 0x0080 : keyValue=3;break;
			case 0x0100 : keyValue=4;break;	
		}while((GPIO_ReadInputData(GPIOB) & 0x01e0)!=0x0000);

	return keyValue;
}

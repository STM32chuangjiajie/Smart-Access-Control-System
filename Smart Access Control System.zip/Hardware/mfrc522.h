#ifndef __mfrc522_H
#define __mfrc522_H
#include "stm32f10x.h"    


//MFRC522�Ĵ���
#define     CommandReg            0x01  
#define     ComIEnReg             0x02  
#define     ComIrqReg             0x04 
#define     DivIrqReg             0x05
#define     ErrorReg              0x06   
#define     Status2Reg            0x08 
#define     FIFODataReg           0x09
#define     FIFOLevelReg          0x0A
#define     ControlReg            0x0C
#define     BitFramingReg         0x0D
#define     CollReg               0x0E
#define     ModeReg               0x11
#define     TxAutoReg             0x15
#define     TxControlReg          0x14
#define     CRCResultRegH         0x21
#define     CRCResultRegL         0x22
#define     TModeReg              0x2A
#define     TPrescalerReg         0x2B
#define     TReloadRegH           0x2C
#define     TReloadRegL           0x2D
#define     TCounterValueRegH     0x2E

//������
#define PCD_IDLE              0x00               //ȡ����ǰ����
#define PCD_CALCCRC           0x03               //CRC����
#define PCD_TRANSCEIVE        0x0C               //���Ͳ���������
#define PCD_AUTHENT           0x0E               //��֤��Կ
#define PCD_RESETPHASE        0x0F               //��λ
#define PICC_READ             0x30               //����
#define PICC_WRITE            0xA0               //д��
#define PICC_ANTICOLL1        0x93               //����ײ


//�����־
#define MI_OK                     0
#define MI_NOTAGERR               1
#define MI_ERR                    2

#define MAX_LEN										18

void Delay1_us(u16 count);
void SPI_W_SS(u8 BitValue);
void SPI_W_SCK(u8 BitValue);
void SPI_W_MOSI(u8 BitValue);
u8 SPI_R_MISO();
void SPI1_Init();
void SPI_Start();
void SPI_Stop();
u8 SPI_Swape(u8 ByteSend);

void MFRC522_Rst(u8 BitValue);
void MFRC522_Write(u8 addr,u8 data);
u8 MFRC522_Read(u8 addr);
void SetBitMask(u8 reg, u8 mask);
void ClearBitMask(u8 reg, u8 mask);
void MFRC522_Reset();
void AntennaOn(void);
void AntennaOff(void);
void MFRC522_Initializtion(void);
u8 MFRC522_ToCard(u8 command, u8 *sendData, u8 sendLen, u8 *backData, u16 *backLen);
u8 MFRC522_Request(u8 reqMode, u8 *TagType);
u8 MFRC522_Anticoll(u8 *serNum);
void CalulateCRC(u8 *pIndata, u8 len, u8 *pOutData);
u8 MFRC522_SelectTag(u8 *serNum);
u8 MFRC522_Auth(u8 authMode, u8 BlockAddr, u8 *Sectorkey, u8 *serNum);
u8 MFRC522_ReadBlock(u8 blockAddr, u8 *recvData);
u8 MFRC522_WriteBlock(u8 blockAddr, u8 *writeData);
#endif 

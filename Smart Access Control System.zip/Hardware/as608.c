#include "stm32f10x.h"                  // Device header
#include	"as608.h"

u8 Head[]={0xEF,0x01};
volatile u8 RX_buff[200];
volatile u8 RX_status = 0;
volatile u8 idx = 0;

Ps_Search_CodeResult SResult;//�������
void USART2_Init(void)
{		
		//����ʱ��
		RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2,ENABLE);
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
		
		GPIO_InitTypeDef GPIO_InitStucture;
		GPIO_InitStucture.GPIO_Mode = GPIO_Mode_AF_PP;//�����������
		GPIO_InitStucture.GPIO_Pin = GPIO_Pin_2;
		GPIO_InitStucture.GPIO_Speed = GPIO_Speed_50MHz;
	  GPIO_Init(GPIOA,&GPIO_InitStucture);
	
		GPIO_InitStucture.GPIO_Mode = GPIO_Mode_IPU;
		GPIO_InitStucture.GPIO_Pin = GPIO_Pin_3;
	  GPIO_Init(GPIOA,&GPIO_InitStucture);
	
		USART_InitTypeDef USART_InitStructure;
		USART_InitStructure.USART_BaudRate = 57600;
		USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
		USART_InitStructure.USART_Mode = USART_Mode_Tx | USART_Mode_Rx;
		USART_InitStructure.USART_Parity = USART_Parity_No;
		USART_InitStructure.USART_StopBits = USART_StopBits_1;
		USART_InitStructure.USART_WordLength = USART_WordLength_8b;
	
		USART_Init(USART2,&USART_InitStructure);//��ʼ������2
		USART_Cmd(USART2,ENABLE);//ʹ�ܴ���2
		USART_ITConfig(USART2,USART_IT_RXNE,ENABLE);//���������ж�
		USART_ITConfig(USART2,USART_IT_IDLE,ENABLE);
		
		NVIC_InitTypeDef NVIC_InitStructure;
		NVIC_InitStructure.NVIC_IRQChannel = USART2_IRQn;
		NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=1 ;//��ռ���ȼ�
		NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;		//�����ȼ�
		NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;			//IRQͨ��ʹ��
		NVIC_Init(&NVIC_InitStructure);	//��ʼ��
}

void AS608_TCHInit(void)
{
	//����ʱ��
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
		
		GPIO_InitTypeDef GPIO_InitStucture;
		GPIO_InitStucture.GPIO_Mode = GPIO_Mode_IPD;
		GPIO_InitStucture.GPIO_Pin = GPIO_Pin_0;
		GPIO_InitStucture.GPIO_Speed = GPIO_Speed_50MHz;
	  GPIO_Init(GPIOA,&GPIO_InitStucture);
}
//�жϴ���
void USART2_IRQHandler(void)
{
	u8 discard;
	if(USART_GetITStatus(USART2,USART_IT_RXNE) == SET)
	{
		if(RX_status == 0)
		{
			RX_buff[idx++] = USART_ReceiveData(USART2);//��������
			if(idx>199){idx = 199;}//��ֹ����Խ�磬�ظ�д������λ��
			USART_ClearITPendingBit(USART2,USART_IT_RXNE);
		}
		else if(RX_status == 1)//�ϸ���δ����
		{
			discard = USART_ReceiveData(USART2);//����
		}
	}
	if(USART_GetITStatus(USART2,USART_IT_IDLE) == SET)
	{
		USART2->SR;
		USART2->DR;
		RX_status = 1;
	}
}

//���ڷ���һ���ֽ�
void USART2_SendByte(u8 data)
{
		USART_SendData(USART2,data);
		while(USART_GetFlagStatus(USART2,USART_FLAG_TXE) == 0);
}

//���ڷ���һ������
//������������(�����׵�ַ)�����鳤��
void USART2_SendArray(u8 *array,u16 length)
{
		u16 i;
		for(i=0;i<length;i++)
		{	
			USART2_SendByte(array[i]);
		}
}
//���ڷ����ַ���
//�������ַ�����ַ
void USART2_SendString(char *string)
{
		u8 i;
		for(i=0;string[i] != 0;i++)
		{
			USART2_SendByte(string[i]);
		}
}


//���Ͱ�ͷ
void Send_PacketHead(void)
{
		USART2_SendArray(Head,2);
}

//�����豸��ַ
void Send_DeviceAddress(void)
{	
		USART2_SendByte((DeviceAddress>>24)& 0xFF);
		USART2_SendByte((DeviceAddress>>16)& 0xFF);
		USART2_SendByte((DeviceAddress>>8)& 0xFF);
		USART2_SendByte(DeviceAddress& 0xFF);
}

//�������ݰ���ʶ
void Send_PacketFlag(u8 flag)
{
		USART2_SendByte(flag);
}

//�������ݰ�����
void Send_PacketLength(u16 length)
{
		USART2_SendByte((length>>8)& 0xFF);
		USART2_SendByte(length& 0xFF);
}

//����ָ����
void Send_Cmd(u8 cmd)
{
		USART2_SendByte(cmd);
}

//����У����
void Send_PacketCheckSum(u16 checksum)
{
		USART2_SendByte((checksum>>8)& 0xFF);
		USART2_SendByte(checksum& 0xFF);
}

//����Ӧ���
u8* Packet_Parse(void)
{
	char *data;
	int x = 2000;
	u8 str[8];
	str[0]=0xEF;					str[1]=0x01;
	str[2]=DeviceAddress>>24&0xFF;	str[3]=DeviceAddress>>16&0xFF;		
	str[4]=DeviceAddress>>8&0xFF;		str[5]=DeviceAddress &0xFF;				
	str[6]=0x07;					str[7]='\0';
		while(--x)
		{
			delay_ms(1);
			if(RX_status == 1)//�Ƿ���������ж�
			{
				RX_status=0;
				idx = 0;
				data=strstr((const char*)RX_buff,(const char*)str);
				if(data)//��ַ�Ƿ�Ϊ��
					return (u8*)data;	
			}
		}
	return 0;
}


















//¼��ͼ��
u8 Ps_GetImage(void)
{		
		u16 checksum;
		u8 ack;
		u8* data;
		Send_PacketHead();
		Send_DeviceAddress();
		Send_PacketFlag(0x01);
		Send_PacketLength(0x03);
		Send_Cmd(0x01);
		checksum = 0x01+0x03+0x01;
		Send_PacketCheckSum(checksum);
		data = Packet_Parse();
		if(data){ack = data[9];}
		else 		{ack = 0x11;}
		return ack;
}

//��������
u8 Ps_Genchar(u8 BufferID)
{
		u16 checksum;
		u8 ack;
		u8* data;
		Send_PacketHead();
		Send_DeviceAddress();
		Send_PacketFlag(0x01);
		Send_PacketLength(0x04);
		Send_Cmd(0x02);
		USART2_SendByte(BufferID);//���ͻ�������
		checksum = 0x01+0x04+0x02+BufferID;
		Send_PacketCheckSum(checksum);
		data = Packet_Parse();
		if(data){ack = data[9];}
		else 		{ack = 0x11;}
		return ack;
}

//����ָ��
u8 Ps_Search(u8 BufferID,u16 StartPage,u16 PageNum)
{
		u16 checksum;
		u8 ack;
		u8* data;
		Send_PacketHead();
		Send_DeviceAddress();
		Send_PacketFlag(0x01);
		Send_PacketLength(0x08);
		Send_Cmd(0x04);
		USART2_SendByte(BufferID);//���ͻ�������
		USART2_SendByte((StartPage>>8)&0xFF);//������ʼҳ
		USART2_SendByte(StartPage&0xFF);
		USART2_SendByte((PageNum>>8)&0xFF);//����ҳ��
		USART2_SendByte(PageNum&0xFF);
		checksum = 0x01+0x08+0x04+BufferID
		+(StartPage>>8)+(u8)StartPage
		+(PageNum>>8)+(u8)PageNum;
		Send_PacketCheckSum(checksum);
		data = Packet_Parse();
		if(data)
		{
			ack = data[9];
			SResult.PageID = (data[10]<<8) | data[11];
			SResult.MatchScore = (data[12]<<8) | data[13];
		}
		else 		{ack = 0x11;}
		return ack;
}

//�ϲ�����
u8 Ps_RegModel(void)
{
		u8 ack;
		u8* data;
		Send_PacketHead();
		Send_DeviceAddress();
		Send_PacketFlag(0x01);
		Send_PacketLength(0x03);
		Send_Cmd(0x05);
		Send_PacketCheckSum(0X09);
		data = Packet_Parse();
		if(data){ack = data[9];}
		else 		{ack = 0x11;}
		return ack;
}

//����ģ��
u8 Ps_StoreChar(u8 BufferID,u16 PageID)
{
		u16 checksum;
		u8 ack;
		u8* data;
		Send_PacketHead();
		Send_DeviceAddress();
		Send_PacketFlag(0x01);
		Send_PacketLength(0x06);
		Send_Cmd(0x06);
		USART2_SendByte(BufferID);
		USART2_SendByte((PageID>>8)&0xFF);//����ָ�ƿ�λ�ú�
		USART2_SendByte(PageID&0xFF);
		checksum = 0x01+0x06+0x06+BufferID+(PageID>>8)+(u8)PageID;
		Send_PacketCheckSum(checksum);
		data = Packet_Parse();
		if(data){ack = data[9];}
		else 		{ack = 0x11;}
		return ack;
}

//ɾ��ģ���ָ��
u8 Ps_DeletChar(u16 PageID)
{
		u16 checksum;
		u8 ack;
		u8* data;
		Send_PacketHead();
		Send_DeviceAddress();
		Send_PacketFlag(0x01);
		Send_PacketLength(0x07);
		Send_Cmd(0x0c);
		USART2_SendByte((PageID>>8)&0xFF);//ɾ��ģ���
		USART2_SendByte(PageID&0xFF);
		USART2_SendByte(0x00); //ɾ������
		USART2_SendByte(0x01);
		checksum =0x01+0x07+0x0c+(PageID>>8)+(u8)PageID+0x01;
		Send_PacketCheckSum(checksum);
		data = Packet_Parse();
		if(data){ack = data[9];}
		else 		{ack = 0x11;}
		return ack;
}
u8 AS608_TouchStatus(void)
{
	return GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_0);
}

